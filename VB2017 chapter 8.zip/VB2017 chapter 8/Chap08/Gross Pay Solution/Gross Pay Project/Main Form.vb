' Name:         Gross Pay Project
' Purpose:      Displays an employee's gross pay.
' Programmer:   <Joseph Grigoletti> on <21 October 2019>

Option Explicit On
Option Strict On
Option Infer Off

Public Class Form1
    Dim rate() As Decimal ''class level array

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim hourlyRate = rate(lstCode.SelectedIndex)
        Dim grossPay As Decimal
        Dim hourWorked As Integer
        hourWorked = Convert.ToInt32(txtHours.Text)
        If hourWorked > 40 Then
            grossPay = 40 * hourlyRate
            grossPay += (hourWorked - 40) * 1.5 * hourWorked
        Else
            grossPay = hourWorked * hourlyRate
        End If
        txtGrossPay.Text = grossPay.ToString("C")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rate = {10.5, 12.5, 14.25, 15.75, 17.68}
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
