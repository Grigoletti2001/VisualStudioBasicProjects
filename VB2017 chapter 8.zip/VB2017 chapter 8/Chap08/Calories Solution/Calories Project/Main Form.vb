﻿' Name:         Calories Solution
' Purpose:      Calculates Estimates Calories.
' Programmer:   <Joseph Grigoletti> on 22 October 2019
Option Explicit On
Option Strict On
Option Infer Off




Public Class Form1
    Public Sub New()

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Public Sub BtnDisplay_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        'declare and initialize a one-dimensional array intCalories
        Dim intCalories() As Integer = {150, 115, 80, 75, 103, 78, 128}
        'variable declarations
        Dim avgNumberOfColories As Integer
        Dim sumOfCalories As Integer
        Dim strResult As String = ""
        Dim numberOfDaysLessThanAvg As Integer = 0
        Dim numberOfDaysGreaterThanAvg As Integer = 0
        Dim numberOfDaysSameAsAvg As Integer = 0

        'calculate the sum of the calories
        For index = 1 To intCalories.Length
            sumOfCalories = sumOfCalories + intCalories(index - 1)
        Next
        'calculate the average number of calories
        avgNumberOfColories = Math.Round(sumOfCalories / intCalories.Length)
        strResult = strResult + "Average number of calories consumed: " + avgNumberOfColories.ToString() + vbNewLine

        For index = 1 To intCalories.Length
            'find number of days in which the daily calories were greater than the average
            If (intCalories(index - 1) > avgNumberOfColories) Then
                numberOfDaysGreaterThanAvg = numberOfDaysGreaterThanAvg + 1
                'find number of days in which the daily calories were less than the average
            ElseIf (intCalories(index - 1) < avgNumberOfColories) Then
                numberOfDaysLessThanAvg = numberOfDaysLessThanAvg + 1
                'find number of days in which the daily calories were same as average
            Else
                numberOfDaysSameAsAvg = numberOfDaysSameAsAvg + 1
            End If
        Next
        'store the results in the string to be displayed
        strResult = strResult + "Number of days in which the daily calories were greater than average: " + numberOfDaysGreaterThanAvg.ToString() + vbNewLine
        strResult = strResult + "Number of days in which the daily calories were less than average: " + numberOfDaysLessThanAvg.ToString() + vbNewLine
        strResult = strResult + "Number of days in which the daily calories were same as average: " + numberOfDaysSameAsAvg.ToString() + vbNewLine

        'display the result
        'lblResult.Text = strResult
    End Sub
End Class