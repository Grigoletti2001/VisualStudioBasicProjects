﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Public Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblAvg = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblAboveAvg = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblAtAvg = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblBelowAvg = New System.Windows.Forms.Label()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(844, 375)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(135, 69)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(304, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(164, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Average daily:"
        '
        'lblAvg
        '
        Me.lblAvg.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblAvg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAvg.Location = New System.Drawing.Point(18, 35)
        Me.lblAvg.Name = "lblAvg"
        Me.lblAvg.Size = New System.Drawing.Size(240, 57)
        Me.lblAvg.TabIndex = 1
        Me.lblAvg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(294, 281)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(189, 32)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Days at average:"
        '
        'lblAboveAvg
        '
        Me.lblAboveAvg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAboveAvg.Location = New System.Drawing.Point(18, 147)
        Me.lblAboveAvg.Name = "lblAboveAvg"
        Me.lblAboveAvg.Size = New System.Drawing.Size(240, 57)
        Me.lblAboveAvg.TabIndex = 3
        Me.lblAboveAvg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(294, 147)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(234, 32)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Days above average:"
        '
        'lblAtAvg
        '
        Me.lblAtAvg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAtAvg.Location = New System.Drawing.Point(18, 269)
        Me.lblAtAvg.Name = "lblAtAvg"
        Me.lblAtAvg.Size = New System.Drawing.Size(243, 44)
        Me.lblAtAvg.TabIndex = 5
        Me.lblAtAvg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(294, 381)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(233, 32)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Days below average:"
        '
        'lblBelowAvg
        '
        Me.lblBelowAvg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBelowAvg.Location = New System.Drawing.Point(18, 373)
        Me.lblBelowAvg.Name = "lblBelowAvg"
        Me.lblBelowAvg.Size = New System.Drawing.Size(240, 40)
        Me.lblBelowAvg.TabIndex = 7
        Me.lblBelowAvg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(844, 113)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(138, 70)
        Me.btnDisplay.TabIndex = 0
        Me.btnDisplay.Text = "&Display"
        Me.btnDisplay.UseVisualStyleBackColor = True

        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.lblAvg)
        Me.GroupBox1.Controls.Add(Me.lblBelowAvg)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.lblAboveAvg)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblAtAvg)
        Me.GroupBox1.Location = New System.Drawing.Point(50, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(580, 443)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 32.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1207, 510)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.btnExit)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Calories Consumed"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Public Sub BtnDisplay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDisplay.Click
        'declare and initialize a one-dimensional array intCalories
        Dim intCalories() As Integer = {150, 115, 80, 75, 103, 78, 128}
        'variable declarations
        Dim avgNumberOfColories As Integer
        Dim sumOfCalories As Integer
        Dim strResult As String = ""
        Dim numberOfDaysLessThanAvg As Integer = 0
        Dim numberOfDaysGreaterThanAvg As Integer = 0
        Dim numberOfDaysSameAsAvg As Integer = 0

        'calculate the sum of the calories
        For index = 1 To intCalories.Length
            sumOfCalories = sumOfCalories + intCalories(index - 1)
        Next
        'calculate the average number of calories
        avgNumberOfColories = Math.Round(sumOfCalories / intCalories.Length)
        strResult = strResult + "Average number of calories consumed: " + avgNumberOfColories.ToString() + vbNewLine

        For index = 1 To intCalories.Length
            'find number of days in which the daily calories were greater than the average
            If (intCalories(index - 1) > avgNumberOfColories) Then
                numberOfDaysGreaterThanAvg = numberOfDaysGreaterThanAvg + 1
                'find number of days in which the daily calories were less than the average
            ElseIf (intCalories(index - 1) < avgNumberOfColories) Then
                numberOfDaysLessThanAvg = numberOfDaysLessThanAvg + 1
                'find number of days in which the daily calories were same as average
            Else
                numberOfDaysSameAsAvg = numberOfDaysSameAsAvg + 1
            End If
        Next
        'store the results in the string to be displayed
        strResult = strResult + "Number of days in which the daily calories were greater than average: " + numberOfDaysGreaterThanAvg.ToString() + vbNewLine
        strResult = strResult + "Number of days in which the daily calories were less than average: " + numberOfDaysLessThanAvg.ToString() + vbNewLine
        strResult = strResult + "Number of days in which the daily calories were same as average: " + numberOfDaysSameAsAvg.ToString() + vbNewLine

        lblAvg.Text = avgNumberOfColories.ToString()
        lblAtAvg.Text = numberOfDaysSameAsAvg.ToString()
        lblAboveAvg.Text = numberOfDaysGreaterThanAvg.ToString()
        lblBelowAvg.Text = numberOfDaysLessThanAvg.ToString()


        'display the result
        'lblResult.Text = strResult
    End Sub

    Public Sub BtnExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Close()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblAvg As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblAboveAvg As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblAtAvg As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblBelowAvg As Label
    Friend WithEvents btnDisplay As Button
    Friend WithEvents GroupBox1 As GroupBox
End Class
