﻿Public Class Form1
    'New Button click
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Dim random As New Random() 'creating object of Random class
        lblNum1.Text = random.Next(1, 10) 'create and display random number between 1 to 10
        lblNum2.Text = random.Next(1, 10) 'create and display random number between 1 to 10
        'disable button to create new problem
        btnNew.Enabled = False
    End Sub
    'check button click
    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        'checking answer entered by user
        If Integer.Parse(lblNum1.Text) + Integer.Parse(lblNum2.Text) = Integer.Parse(txtAnswer.Text) Then
            'if addition of two numbers are equal to answer then display message box
            MessageBox.Show("Answer iscorrect")
            'enable button to create new problem
            btnNew.Enabled = True

            'clear random numbers
            lblNum1.Text = ""
            lblNum2.Text = ""
            txtAnswer.Text = ""
        Else
            'if answer is incorrect then display
            MessageBox.Show("Please try again")
        End If
    End Sub
    'Exit button click
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close() 'close the form
    End Sub
End Class