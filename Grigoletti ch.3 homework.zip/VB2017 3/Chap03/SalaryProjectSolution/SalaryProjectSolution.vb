﻿
' Name: Property Tax Solution Program
' Purpose: Calculates and displays an homeowns estimated property tax
' Name: Joseph Grigoletti
' date: 9 september 2019

Option Explicit On
Option Strict On
Option Infer Off


Public Class SalaryProjectSolution
    Private Sub Textsales_Click(sender As Object, e As EventArgs) Handles textsales.Click

    End Sub

    Private Sub BtnCalc5_Click(sender As Object, e As EventArgs) Handles btnCalc5.Click


        Dim salesAmt As Decimal = Convert.ToDecimal(salesAmount.Text)

        Dim salesTaxAmt As Decimal = salesAmt * 0.05

        Dim totalDue As Decimal = salesAmt + salesTaxAmt




        lblTotal.Text = totalDue.ToString("N2")




    End Sub

    Private Sub BtnCalc8_Click(sender As Object, e As EventArgs) Handles btnCalc8.Click


        Dim salesAmt As Decimal = Convert.ToDecimal(salesAmount.Text)

        Dim salesTaxAmt As Decimal = salesAmt * 0.08

        Dim totalDue As Decimal = salesAmt + salesTaxAmt



        lblTotal.Text = totalDue.ToString("N2")




    End Sub

    Private Sub SalesAmount_TextChanged(sender As Object, e As EventArgs) Handles salesAmount.TextChanged



    End Sub

    Private Sub LblTotal_Click(sender As Object, e As EventArgs) Handles lblTotal.Click

    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class
