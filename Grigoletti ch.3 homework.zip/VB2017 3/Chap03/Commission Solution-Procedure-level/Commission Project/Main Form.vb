﻿' Name: Property Tax Solution Program
' Purpose: Calculates and displays an homeowns estimated property tax
' Name: Joseph Grigoletti
' date: 9 september 2019

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnRate10_Click(sender As Object, e As EventArgs) Handles btnRate10.Click
        ' Calculates and displays a 10% commission.

        ' Declare two procedure-level variables that can
        ' be used only within the btnRate10_Click procedure.

        Dim decSales As Decimal
        Dim decCom10 As Decimal





        ' Convert the txtSales.Text property to Decimal. Store
        ' the result in the procedure-level decSales variable.

        Decimal.TryParse(txtSales.Text, decSales)


        ' Multiply the value in the procedure-level decSales
        ' variable by the Decimal number 0.1D. Assign the
        ' result to the procedure-level decComm10 variable.


        decCom10 = decSales * 0.1D


        ' Convert the value in the procedure-level decComm10
        ' variable to String. Assign the result to the
        ' lblCommission.Text property.


        lblCommission.Text = decCom10.ToString("C2")


    End Sub


    Private Sub btnRate8_Click(sender As Object, e As EventArgs) Handles btnRate8.Click
        ' Calculates and displays an 8% commission.

        ' Declare two procedure-level variables that can
        ' be used only within the btnRate8_Click procedure.

        Dim decSales As Decimal
        Dim decCom8 As Decimal


        ' Convert the txtSales.Text property to Decimal. Store
        ' the result in the procedure-level decSales variable.


        Decimal.TryParse(txtSales.Text, decSales)


        ' Multiply the value in the procedure-level decSales
        ' variable by the Decimal number 0.08D. Assign the
        ' result to the procedure-level decComm8 variable.

        decCom8 = decSales * 0.08D



        ' Convert the value in the procedure-level decComm8
        ' variable to String. Assign the result to the
        ' lblCommission.Text property.


        lblCommission.Text = decCom8.ToString("C2")


    End Sub

    Private Sub LblCommission_Click(sender As Object, e As EventArgs) Handles lblCommission.Click

    End Sub
End Class
