﻿' Name: Property Tax Solution Program
' Purpose: Calculates and displays an homeowns estimated property tax
' Name: Joseph Grigoletti
' date: 9 september 2019

Option Explicit On
Option Strict On
Option Infer Off

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.houseTax = New System.Windows.Forms.PictureBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.salesAmount = New System.Windows.Forms.TextBox()
        Me.lblTax = New System.Windows.Forms.TextBox()
        Me.textsales = New System.Windows.Forms.Label()
        Me.text2 = New System.Windows.Forms.Label()
        Me.text3 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.houseTax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'houseTax
        '
        Me.houseTax.Image = CType(resources.GetObject("houseTax.Image"), System.Drawing.Image)
        Me.houseTax.Location = New System.Drawing.Point(12, -6)
        Me.houseTax.Name = "houseTax"
        Me.houseTax.Size = New System.Drawing.Size(1253, 553)
        Me.houseTax.TabIndex = 0
        Me.houseTax.TabStop = False
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Location = New System.Drawing.Point(527, 342)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(173, 78)
        Me.lblTotal.TabIndex = 1
        '
        'salesAmount
        '
        Me.salesAmount.Location = New System.Drawing.Point(537, 146)
        Me.salesAmount.Name = "salesAmount"
        Me.salesAmount.Size = New System.Drawing.Size(173, 20)
        Me.salesAmount.TabIndex = 4
        '
        'lblTax
        '
        Me.lblTax.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTax.Location = New System.Drawing.Point(537, 230)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(173, 20)
        Me.lblTax.TabIndex = 9
        '
        'textsales
        '
        Me.textsales.AutoSize = True
        Me.textsales.Location = New System.Drawing.Point(716, 146)
        Me.textsales.Name = "textsales"
        Me.textsales.Size = New System.Drawing.Size(76, 13)
        Me.textsales.TabIndex = 10
        Me.textsales.Text = "&Housing Value"
        '
        'text2
        '
        Me.text2.AutoSize = True
        Me.text2.Location = New System.Drawing.Point(716, 232)
        Me.text2.Name = "text2"
        Me.text2.Size = New System.Drawing.Size(67, 13)
        Me.text2.TabIndex = 11
        Me.text2.Text = "Property Tax"
        '
        'text3
        '
        Me.text3.AutoSize = True
        Me.text3.Location = New System.Drawing.Point(715, 381)
        Me.text3.Name = "text3"
        Me.text3.Size = New System.Drawing.Size(55, 13)
        Me.text3.TabIndex = 12
        Me.text3.Text = "Total due:"
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(527, 450)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(173, 23)
        Me.btnCalc.TabIndex = 13
        Me.btnCalc.Text = "&Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(527, 490)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(173, 23)
        Me.btnExit.TabIndex = 14
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(799, 534)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.text3)
        Me.Controls.Add(Me.text2)
        Me.Controls.Add(Me.textsales)
        Me.Controls.Add(Me.lblTax)
        Me.Controls.Add(Me.salesAmount)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.houseTax)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.houseTax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents houseTax As PictureBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents salesAmount As TextBox
    Friend WithEvents lblTax As TextBox
    Friend WithEvents textsales As Label
    Friend WithEvents text2 As Label
    Friend WithEvents text3 As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
End Class
