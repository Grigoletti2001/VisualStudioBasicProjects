﻿' Name: Property Tax Solution Program
' Purpose: Calculates and displays an homeowns estimated property tax
' Name: Joseph Grigoletti
' date: 9 september 2019

Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblTotal.Click

    End Sub

    ' Option Explicit On
    ' Option Infer Off
    ' Option Infer Off


    Private Sub Label1_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub HouseValue_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click


        Dim salesAmt As Decimal = Convert.ToDecimal(salesAmount.Text)

        Dim salesTaxAmt As Decimal = 0.05 * salesAmt

        Dim totalDue As Decimal = salesAmt + salesTaxAmt


        lblTax.Text = salesTaxAmt.ToString("N2")

        lblTotal.Text = totalDue.ToString("N2")













    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class
