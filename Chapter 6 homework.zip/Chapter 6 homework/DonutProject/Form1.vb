﻿' Name:         donut app
' Purpose:      displays price at donut price
' Programmer:   <Joseph Grigoletti> on 
Option Explicit On
Option Strict On
Option Infer Off

Public Class Form1


    Private Sub Forum1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged

    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged

    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged

    End Sub

    Private Sub Quit_Click(sender As Object, e As EventArgs) Handles quit.Click



        '' closes application
        Me.Close()
        Application.Exit()

    End Sub

    Private Sub Calculate_Click(sender As Object, e As EventArgs) Handles calculate.Click
        '' calculate button click event handler




    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter



    End Sub
End Class

Public Class Form1

    ' Exit button click event handler
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    ' Calculate button click event handler
    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        Dim subTotal = 0, salesTax, totalDue As Double

        ' Checking doughnuts choices
        If rbGlazed.Checked Then
            ' Accumulating total
            subTotal = subTotal + 1.05
        ElseIf rbSugar.Checked Then
            ' Accumulating total
            subTotal = subTotal + 1.05
        ElseIf rbChocolate.Checked Then
            ' Accumulating total
            subTotal = subTotal + 1.25
        ElseIf rbFilled.Checked Then
            ' Accumulating total
            subTotal = subTotal + 1.05
        End If

        ' Checking coffee choices
        If rbRegular.Checked Then
            ' Accumulating total
            subTotal = subTotal + 1.5
        ElseIf rbCappuccino.Checked Then
            ' Accumulating total
            subTotal = subTotal + 2.75
        End If

        ' Calculating sales tax
        salesTax = subTotal * 0.06

        ' Calculating total due
        totalDue = subTotal - salesTax

        ' Writing results to textboxes
        tbSubTotal.Text = "$" + subTotal.ToString("0.00")
        tbSalesTax.Text = "$" + salesTax.ToString("0.00")
        tbTotalDue.Text = "$" + totalDue.ToString("0.00")

    End Sub

End Class