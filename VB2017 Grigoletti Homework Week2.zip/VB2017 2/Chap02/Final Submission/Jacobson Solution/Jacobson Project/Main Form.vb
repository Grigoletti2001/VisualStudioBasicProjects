﻿' Name:         Jacobson Solution
' Purpose:      Calculate and display the sales tax and total due.
' Programmer:   <Joseph Grigoletti> on <09 sept. 2019>

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub LblTax_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click_1(sender As Object, e As EventArgs) Handles text2.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles textsales.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles salesAmount.TextChanged

    End Sub

    Private Sub LblTax_TextChanged(sender As Object, e As EventArgs) Handles lblTax.TextChanged



    End Sub

    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        Dim salesAmt As Decimal = Convert.ToDecimal(salesAmount.Text)

        Dim salesTaxAmt As Decimal = 0.05 * salesAmt

        Dim totalDue As Decimal = salesAmt + salesTaxAmt


        lblTax.Text = salesTaxAmt.ToString("N2")

        lblTotal.Text = totalDue.ToString("N2")





    End Sub
End Class
