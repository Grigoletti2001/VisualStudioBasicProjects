﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SalaryProjectSolution
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SalaryProjectSolution))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.textsales = New System.Windows.Forms.Label()
        Me.salesAmount = New System.Windows.Forms.TextBox()
        Me.salaryLabel = New System.Windows.Forms.Label()
        Me.btnCalc5 = New System.Windows.Forms.Button()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.btnCalc8 = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(412, 409)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'textsales
        '
        Me.textsales.AutoSize = True
        Me.textsales.Location = New System.Drawing.Point(485, 12)
        Me.textsales.Name = "textsales"
        Me.textsales.Size = New System.Drawing.Size(0, 7)
        Me.textsales.TabIndex = 11
        '
        'salesAmount
        '
        Me.salesAmount.BackColor = System.Drawing.SystemColors.Info
        Me.salesAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.salesAmount.Location = New System.Drawing.Point(433, 84)
        Me.salesAmount.Name = "salesAmount"
        Me.salesAmount.Size = New System.Drawing.Size(323, 20)
        Me.salesAmount.TabIndex = 12
        '
        'salaryLabel
        '
        Me.salaryLabel.AutoSize = True
        Me.salaryLabel.Location = New System.Drawing.Point(430, 47)
        Me.salaryLabel.Name = "salaryLabel"
        Me.salaryLabel.Size = New System.Drawing.Size(74, 13)
        Me.salaryLabel.TabIndex = 13
        Me.salaryLabel.Text = "&Salary amount"
        '
        'btnCalc5
        '
        Me.btnCalc5.Location = New System.Drawing.Point(433, 236)
        Me.btnCalc5.Name = "btnCalc5"
        Me.btnCalc5.Size = New System.Drawing.Size(137, 23)
        Me.btnCalc5.TabIndex = 14
        Me.btnCalc5.Text = "&Calculate a 5% raise"
        Me.btnCalc5.UseVisualStyleBackColor = True
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Location = New System.Drawing.Point(512, 297)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(165, 23)
        Me.lblTotal.TabIndex = 15
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnCalc8
        '
        Me.btnCalc8.Location = New System.Drawing.Point(619, 236)
        Me.btnCalc8.Name = "btnCalc8"
        Me.btnCalc8.Size = New System.Drawing.Size(137, 23)
        Me.btnCalc8.TabIndex = 16
        Me.btnCalc8.Text = "&Calculate an 8% raise"
        Me.btnCalc8.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(530, 373)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(122, 23)
        Me.btnExit.TabIndex = 17
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'SalaryProjectSolution
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc8)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.btnCalc5)
        Me.Controls.Add(Me.salaryLabel)
        Me.Controls.Add(Me.salesAmount)
        Me.Controls.Add(Me.textsales)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "SalaryProjectSolution"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents textsales As Label
    Friend WithEvents salesAmount As TextBox
    Friend WithEvents salaryLabel As Label
    Friend WithEvents btnCalc5 As Button
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnCalc8 As Button
    Friend WithEvents btnExit As Button
End Class
