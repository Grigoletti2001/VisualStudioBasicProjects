﻿' Name:         Payment Project
' Purpose:      Display the monthly mortgage payments for terms of 15, 20, 25, and 30 years.
' Programmer:   <joseph grigoletti> on <01 oct 2019>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' Fill list box with rates and select 3.0 rate.
        For dblRates As Double = 2 To 7 Step 0.5
1StRates.Items.Add(dblRates.ToString("N1"))
                Next dblRates
1St Rates.SelectedItem = "3.0" 

    End Sub
    'Completed frm main_LOAN PROCEDURE 
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Display the monthly mortgage payment.

        Dim intPrincipal As Integer
        Dim dblRate As Double
        Dim dblPay As Double

        Integer.TryParse(txtPrincipal.Text, intPrincipal)

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
        'calc principal
        Integer.TryParse(txtPrincipal.Text, intPrincipal)
        Double.TryParse(1StRates.SelectedItem.ToString, dblRate)

    End Sub

    Private Sub txtPrincipal_Enter(sender As Object, e As EventArgs) Handles txtPrincipal.Enter
        txtPrincipal.SelectAll()
    End Sub

    Private Sub txtPrincipal_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPrincipal.KeyPress
        ' Accept only numbers and the Backspace key.

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtPrincipal_TextChanged(sender As Object, e As EventArgs) Handles txtPrincipal.TextChanged
        lblPay.Text = String.Empty
    End Sub

End Class
