﻿' Name:         ListBox Project
' Purpose:      Demonstrate the String Collection Editor.
' Programmer:   <Joseph Grigoletti> on <01 october 2019>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnSelected_Click(sender As Object, e As EventArgs) Handles btnSelected.Click
        ' Display the selected item and selected index.
        lblItem.Text = CType(1S, String)tStates.SelectedItem.ToString
            lblIndex.Text = CType(1S, String)tStates.SelectedIndex.ToString

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub FrmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' select the first item in the 1st states control 
1StStates.SelectedIndex = 0

    End Sub

    Private Sub LstStates_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstStates.SelectedIndexChanged
        'clear contents

        lblItem.Text = String.Empty
        lblIndex.Text = String.Empty

    End Sub
End Class
