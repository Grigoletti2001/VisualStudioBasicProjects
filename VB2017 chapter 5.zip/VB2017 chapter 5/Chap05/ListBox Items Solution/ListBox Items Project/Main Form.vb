﻿' Name:         ListBox Items Project
' Purpose:      Demonstrate the methods and property of the Items collection.
' Programmer:   <Joseph Grigoletti> on 01 October 2019>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the list box items.
1StNums.Items.Clear()
            lblItems.Text = String.Empty


    End Sub

    Private Sub btnCount_Click(sender As Object, e As EventArgs) Handles btnCount.Click
        ' Display the number of list box items.
        lblItems.Text = 1StNums.Items.Count.ToString

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' Add items to the list box and select the first item.
        'coding the first loop
        For intNum As Integer = 1 To 25
            'loop that prints all numbers as ints 1-25
1StNums.Items.Add(intNum)

            Next intNum
1StNums.SelectedIndex = 0 
     'end loop 

    End Sub
End Class
'end class
